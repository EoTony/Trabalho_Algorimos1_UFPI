#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(){
    char comando[512];
    char executavel[128];
    char cwd[1024];
    
    // Obtém o diretório atual
    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        printf("[ERRO] Nao foi possivel obter o diretorio atual.\n");
        return 1;
    }
    
    // Verifica se os diretórios necessários existem no diretório atual
    if (access("src", F_OK) != 0 || access("include", F_OK) != 0) {
        // Tenta subir um nível (para quando executado de output/ pelo VS Code)
        if (chdir("..") == 0) {
            if (access("src", F_OK) == 0 && access("include", F_OK) == 0) {
                // Encontrou! Atualiza o diretório atual
                if (getcwd(cwd, sizeof(cwd)) == NULL) {
                    printf("[ERRO] Nao foi possivel obter o diretorio atual.\n");
                    return 1;
                }
                printf("Detectado execucao de subdiretorio.\n");
            } else {
                // Não encontrou nem subindo um nível
                printf("[ERRO] Diretorios 'src' ou 'include' nao encontrados!\n");
                printf("Certifique-se de executar este programa na raiz do projeto.\n");
                printf("\nUso correto:\n");
                printf("  cd /caminho/para/NewNevergithub\n");
                printf("  gcc -o compile compile.c\n");
                printf("  ./compile\n");
                return 1;
            }
        } else {
            printf("[ERRO] Diretorios 'src' ou 'include' nao encontrados!\n");
            printf("Certifique-se de executar este programa na raiz do projeto.\n");
            return 1;
        }
    }
    
    printf("Diretorio de trabalho: %s\n\n", cwd);
    
    // Detectando o sistema operacional
    #ifdef _WIN32
        // Windows - usa caminhos relativos e barra invertida
        strcpy(comando, "gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor.exe src\\main.c src\\abelha.c src\\sensor.c src\\utils.c src\\relatorios.c");
        strcpy(executavel, "beemonitor.exe");
    #else
        // Linux, macOS ou outros sistemas Unix-like
        strcpy(comando, "gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor src/main.c src/abelha.c src/sensor.c src/utils.c src/relatorios.c");
        strcpy(executavel, "./beemonitor");
    #endif

    printf("===========================================\n");
    printf("   Compilador BeeMonitor v1.0\n");
    printf("===========================================\n\n");
    printf("Compilando o projeto BeeMonitor...\n");

    // Executa o comando de compilação
    int retorno = system(comando);

    // Verifica se a compilação foi bem-sucedida
    if (retorno == 0)
    {
        printf("\n[OK] Compilacao concluida com sucesso!\n");
        printf("Executando o programa...\n");
        printf("===========================================\n\n");
        system(executavel);
    }
    else
    {
        printf("\n[ERRO] Falha na compilacao. Codigo de retorno: %d\n", retorno);
        printf("\nVerifique:\n");
        printf("  1. Se voce esta no diretorio raiz do projeto\n");
        printf("  2. Se todos os arquivos .c existem em src/\n");
        printf("  3. Se o GCC esta instalado (gcc --version)\n");
        printf("  4. Se ha erros de sintaxe nos arquivos fonte\n");
    }

    return 0;
}
