# 🐝 BeeMonitor - Compilação com compile.c

Sistema de monitoramento de colmeias desenvolvido em C.

---

## 📋 Pré-requisitos

- **GCC** (GNU Compiler Collection)

### Instalar GCC:

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install gcc
```

**Linux (Fedora):**
```bash
sudo dnf install gcc
```

**macOS:**
```bash
xcode-select --install
```

**Windows:**
- Baixe e instale o [MinGW](https://www.mingw-w64.org/)
- Ou instale o [MSYS2](https://www.msys2.org/)

### Verificar instalação:
```bash
gcc --version
```

---

## 🚀 Como Usar o compile.c

O `compile.c` é um **script portátil de compilação** que funciona em **qualquer sistema operacional**.

---

## 📖 Uso Passo a Passo

### 1. Compile o compile.c (apenas na primeira vez):

**Opção A - Da raiz do projeto:**
```bash
cd /home/ufpi/NewNevergithub
gcc -o compile compile.c
```

**Opção B - Compilar para output/ (para usar com VS Code):**
```bash
cd /home/ufpi/NewNevergithub
gcc -o output/compile compile.c
```

### 2. Execute:

**Da raiz:**
```bash
cd /home/ufpi/NewNevergithub
./compile
```

**De qualquer subdiretório:**
```bash
cd /home/ufpi/NewNevergithub/output
./compile
```

### 3. Apenas executar o beemonitor (sem recompilar):
```bash
./beemonitor
```

---

## 📖 Uso no Windows

### 1. Abra o Prompt de Comando (cmd)

### 2. Navegue até o diretório do projeto:
```cmd
cd C:\Users\SeuNome\Desktop\NewNevergithub
```

### 3. Compile o compile.c (apenas na primeira vez):
```cmd
gcc -o compile.exe compile.c
```

### 4. Execute o compile:
```cmd
compile.exe
```

**Pronto!** O programa irá:
- ✅ Compilar todo o projeto BeeMonitor
- ✅ Criar o executável `beemonitor.exe`
- ✅ Executar automaticamente

---

## 💻 Uso no VS Code

### Método 1: Botão Run (Recomendado)
1. Compile o `compile.c` para o diretório `output/`:
   ```bash
   gcc -o output/compile compile.c
   ```
2. Abra o arquivo `compile.c` no VS Code
3. Clique no botão **▶ Run** no canto superior direito
4. Pronto! O programa detecta automaticamente que está em `output/` e sobe para a raiz

### Método 2: Terminal Integrado
1. Abra o terminal no VS Code (Ctrl + `)
2. Execute:
   ```bash
   cd /home/ufpi/NewNevergithub
   gcc -o compile compile.c
   ./compile
   ```

---

## 🎯 Vantagens do compile.c

✅ **Portátil** - Funciona em Linux, macOS e Windows  
✅ **Simples** - Apenas um comando para compilar e executar  
✅ **Inteligente** - Detecta automaticamente o diretório correto  
✅ **Compatível com VS Code** - Funciona mesmo executado de subdiretórios  
✅ **Sem dependências extras** - Só precisa do GCC  
✅ **Fácil para iniciantes** - Não precisa entender Makefiles

---

## 📁 O que o compile.c Faz

1. **Detecta o sistema operacional** (Linux/Windows/macOS)
2. **Verifica o diretório atual** e procura por `src/` e `include/`
3. **Sobe automaticamente** um nível se executado de `output/` (compatível com VS Code)
4. **Encontra a raiz do projeto** automaticamente
5. **Compila todos os arquivos .c** de uma vez
6. **Cria o executável** `beemonitor` (ou `beemonitor.exe` no Windows)
7. **Executa automaticamente** o programa

### Exemplo de saída (executando da raiz):
```
Diretorio de trabalho: /home/ufpi/NewNevergithub

===========================================
   Compilador BeeMonitor v1.0
===========================================

Compilando o projeto BeeMonitor...

[OK] Compilacao concluida com sucesso!
Executando o programa...
===========================================

[Saída do programa...]
```

### Exemplo de saída (executando de subdiretório):
```
Detectado execucao de subdiretorio.
Diretorio de trabalho: /home/ufpi/NewNevergithub

===========================================
   Compilador BeeMonitor v1.0
===========================================

Compilando o projeto BeeMonitor...

[OK] Compilacao concluida com sucesso!
Executando o programa...
===========================================

[Saída do programa...]
```

---

## 🔄 Workflow Típico

### Primeira vez (Terminal):
```bash
# 1. Vá para a raiz do projeto
cd /home/ufpi/NewNevergithub

# 2. Compile o compile.c
gcc -o compile compile.c

# 3. Execute
./compile
```

### Primeira vez (VS Code):
```bash
# 1. Compile para o diretório output
gcc -o output/compile compile.c

# 2. Clique no botão ▶ Run no VS Code
```

### Após modificar o código:
```bash
# Apenas execute novamente (de qualquer lugar)
./compile
```

### Executar apenas o beemonitor (sem recompilar):
```bash
./beemonitor
```

---

## ⚙️ Como Funciona Internamente

O `compile.c` detecta automaticamente o sistema operacional:

**No Linux/macOS:**
```c
gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor \
    src/main.c src/abelha.c src/sensor.c src/utils.c src/relatorios.c
```

**No Windows:**
```c
gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor.exe \
    src\main.c src\abelha.c src\sensor.c src\utils.c src\relatorios.c
```

---

## ❓ Solução de Problemas

### Erro: "gcc: command not found"
**Solução:** O GCC não está instalado. Veja a seção **Pré-requisitos**.

### Erro: "Diretorios 'src' ou 'include' nao encontrados"
**Solução:** O programa não conseguiu encontrar a raiz do projeto. Isso acontece se você executar de um diretório muito profundo (mais de 1 nível). Navegue manualmente:
```bash
cd /caminho/correto/NewNevergithub
./compile
```

### Erro: "src/main.c: No such file or directory"
**Solução:** 
1. Verifique se os arquivos existem em `src/`
2. Certifique-se de estar executando da raiz do projeto

### No Windows: "compile.exe" não executa
**Solução:** Use o caminho completo:
```cmd
.\compile.exe
```

### Erro de permissão no Linux
**Solução:** Dê permissão de execução:
```bash
chmod +x compile
./compile
```

---

## 🌍 Portabilidade Total

O `compile.c` é **100% portátil e inteligente**! 

✅ **Não precisa editar nada** - funciona em qualquer caminho  
✅ **Detecta automaticamente** o diretório correto  
✅ **Sobe um nível** automaticamente se executado de subdiretório  
✅ **Compatível com VS Code** - funciona no botão Run  
✅ **Funciona** em Linux, macOS e Windows sem modificação

**Execute de qualquer lugar:**
```bash
# Da raiz
cd /qualquer/caminho/para/o/projeto
./compile

# De um subdiretório (como output/)
cd /qualquer/caminho/para/o/projeto/output
./compile
```

Se você mover ou copiar o projeto para outro computador, ele continuará funcionando!

---

## 🔧 Personalização

### Adicionar flags de debug:
Edite o `compile.c` e adicione `-g -O0`:
```c
strcpy(comando, "gcc -Wall -Wextra -std=c11 -g -O0 -Iinclude -o beemonitor ...");
```

### Adicionar otimizações:
Adicione `-O3`:
```c
strcpy(comando, "gcc -Wall -Wextra -std=c11 -O3 -Iinclude -o beemonitor ...");
```

---

## 🆚 compile.c vs Makefile

| Característica | compile.c | Makefile |
|----------------|-----------|----------|
| **Portabilidade** | ✅ Windows/Linux/macOS | ⚠️ Precisa de Make no Windows |
| **Simplicidade** | ✅ Muito simples | ⚠️ Precisa entender sintaxe |
| **Velocidade** | ⚠️ Recompila tudo sempre | ✅ Compila apenas modificados |
| **Para iniciantes** | ✅ Ideal | ⚠️ Curva de aprendizado |
| **Projetos grandes** | ⚠️ Pode ser lento | ✅ Mais eficiente |

**Recomendação:**
- 👨‍🎓 **Iniciantes/Windows:** Use `compile.c`
- 👨‍💻 **Avançados/Linux:** Use `Makefile`

---

## 🌐 Compatibilidade

- ✅ **Linux** (todas as distribuições)
- ✅ **macOS** (com Xcode Command Line Tools)
- ✅ **Windows** (com MinGW/MSYS2)
- ✅ **VS Code** (qualquer plataforma)

---

## 📝 Notas Importantes

- O `compile.c` recompila **tudo** sempre (pode ser lento em projetos grandes)
- O executável é criado na **raiz do projeto**
- Funciona mesmo se executado de outro diretório (muda automaticamente)
- Mensagens de erro são claras e em português

---

## 🆘 Precisa de Ajuda?

Se o `compile.c` falhar, ele mostra:
```
[ERRO] Falha na compilacao. Codigo de retorno: 256

Verifique:
  1. Se voce esta no diretorio raiz do projeto
  2. Se todos os arquivos .c existem em src/
  3. Se o GCC esta instalado (gcc --version)
  4. Se ha erros de sintaxe nos arquivos fonte
```

Siga as instruções na tela!

---

**Sistema operacional:** Todos (Windows/Linux/macOS)  
**Método:** compile.c (script portátil)  
**Nível:** Iniciante/Intermediário
