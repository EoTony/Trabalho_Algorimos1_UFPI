# 🐝 BeeMonitor - Compilação com Makefile

Sistema de monitoramento de colmeias desenvolvido em C.

---

## 📋 Pré-requisitos

- **GCC** (GNU Compiler Collection)
- **Make**

### Instalar no Linux:

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install build-essential
```

**Fedora:**
```bash
sudo dnf install gcc make
```

### Instalar no macOS:
```bash
xcode-select --install
```

### Verificar instalação:
```bash
gcc --version
make --version
```

---

## 🚀 Como Usar o Makefile

### Comandos Disponíveis:

```bash
# Compilar o projeto
make

# Compilar e executar
make run

# Limpar arquivos compilados
make clean

# Recompilar tudo do zero
make rebuild

# Ver ajuda com todos os comandos
make help
```

---

## 📖 Uso Passo a Passo

### 1. Navegue até o diretório do projeto:
```bash
cd /home/ufpi/NewNevergithub
```

### 2. Compile e execute:
```bash
make run
```

### 3. Apenas compilar (sem executar):
```bash
make
```

### 4. Executar o programa já compilado:
```bash
./beemonitor
```

### 5. Limpar arquivos compilados:
```bash
make clean
```

---

## 🎯 Vantagens do Makefile

✅ **Compilação incremental** - Recompila apenas arquivos modificados  
✅ **Organização** - Arquivos objeto ficam no diretório `obj/`  
✅ **Velocidade** - Mais rápido em projetos grandes  
✅ **Padrão da indústria** - Usado profissionalmente  
✅ **Comandos simples** - `make run` é fácil de lembrar

---

## 📁 O que o Makefile Faz

1. **Compila cada arquivo .c** individualmente em arquivos .o
2. **Armazena objetos** no diretório `obj/`
3. **Liga tudo** em um executável final chamado `beemonitor`
4. **Detecta mudanças** e recompila apenas o necessário

### Exemplo de saída:
```
Compilando src/main.c...
Compilando src/abelha.c...
Compilando src/sensor.c...
Compilando src/utils.c...
Compilando src/relatorios.c...
Linkando beemonitor...
Compilacao concluida com sucesso!
Executando o programa...
```

---

## 📂 Estrutura de Arquivos Gerada

```
NewNevergithub/
├── Makefile           ← Arquivo de build
├── beemonitor         ← Executável final
├── obj/               ← Arquivos objeto (.o)
│   ├── main.o
│   ├── abelha.o
│   ├── sensor.o
│   ├── utils.o
│   └── relatorios.o
├── src/               ← Código fonte
└── include/           ← Headers
```

---

## ⚙️ Personalizar o Makefile

Se quiser modificar flags de compilação, edite estas linhas no `Makefile`:

```makefile
CC = gcc                           # Compilador
CFLAGS = -Wall -Wextra -std=c11   # Flags de compilação
```

### Adicionar flags de debug:
```makefile
CFLAGS = -Wall -Wextra -std=c11 -g -O0
```

### Adicionar otimizações:
```makefile
CFLAGS = -Wall -Wextra -std=c11 -O3
```

---

## ❓ Solução de Problemas

### Erro: "make: command not found"
**Solução:** Instale o Make:
```bash
sudo apt install make
```

### Erro: "gcc: command not found"
**Solução:** Instale o GCC:
```bash
sudo apt install build-essential
```

### Erro: "No rule to make target"
**Solução:** Certifique-se de estar no diretório correto:
```bash
cd /home/ufpi/NewNevergithub
pwd  # Deve mostrar: /home/ufpi/NewNevergithub
```

### Compilação não detecta mudanças
**Solução:** Force recompilação completa:
```bash
make rebuild
```

### Permissão negada ao executar
**Solução:** Dê permissão de execução:
```bash
chmod +x beemonitor
./beemonitor
```

---

## 🔄 Workflow Recomendado

1. **Primeira vez:**
   ```bash
   make run
   ```

2. **Após modificar código:**
   ```bash
   make run
   ```
   *(Recompila apenas arquivos modificados)*

3. **Antes de entregar o projeto:**
   ```bash
   make clean
   ```
   *(Remove arquivos temporários)*

---

## 🌐 Compatibilidade

- ✅ **Linux** (todas as distribuições)
- ✅ **macOS** (com Xcode Command Line Tools)
- ⚠️ **Windows** (requer MinGW/MSYS2 ou WSL)
  - Para Windows nativo, prefira usar o `compile.c` (veja README-compile.md)

---

## 📝 Notas Importantes

- O Makefile usa caminhos relativos, funciona de qualquer lugar
- Arquivos `.o` são automaticamente organizados no diretório `obj/`
- O executável `beemonitor` é criado na raiz do projeto
- Use `make clean` antes de commitar no Git

---

## 🆘 Precisa de Ajuda?

Execute para ver todos os comandos:
```bash
make help
```

---

**Sistema operacional:** Linux/macOS  
**Método:** Makefile  
**Nível:** Intermediário/Avançado
