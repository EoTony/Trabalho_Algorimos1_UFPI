#ifndef UTILS_H
#define UTILS_H

/* Função utilitária para limpar o buffer de entrada */
void limpezaBuffer(void);

#endif
