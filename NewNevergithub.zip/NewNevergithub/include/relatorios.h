#ifndef RELATORIOS_H
#define RELATORIOS_H

#include "types.h"

/* Módulo de relatórios e estatísticas */

/* Calcula a temperatura média dos sensores de temperatura */
double temperaturaMedia(Sensor p[]);

/* Conta quantas abelhas existem em uma região específica */
int quantidadePorRegiao(Abelha p[], char regiao[]);

/* Calcula a produção média de mel de todas as abelhas */
double producaoMediaMel(Abelha p[]);

#endif
