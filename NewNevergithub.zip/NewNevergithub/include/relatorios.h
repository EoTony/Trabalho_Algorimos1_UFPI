#ifndef RELATORIOS_H
#define RELATORIOS_H

#include "types.h"

int quantidadePorRegiao(Abelha p[], char regiao[]);
double producaoMediaMel(Abelha p[]);
double temperaturaMedia(Sensor p[]);

#endif
