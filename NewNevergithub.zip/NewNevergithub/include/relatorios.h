#ifndef RELATORIOS_H
#define RELATORIOS_H

#include "types.h"

//Protótipo de função: Indica a existencia de função X e ela recebe tal resultado
//Permite chamar as funções definidas em um arquivo .c

int quantidadePorRegiao(Abelha p[], char regiao[]);
double producaoMediaMel(Abelha p[]);
double temperaturaMedia(Sensor p[]);

#endif
