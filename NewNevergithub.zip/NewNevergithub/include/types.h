#ifndef TYPES_H
#define TYPES_H

typedef struct {
    int id;
    char tipo[30];
    float valor;
    int idAbelha;
} Sensor;
//BASE. Estrutura de dados para indexar o Sensor:
//Quando a Base "Sensor" for chamada em uma função, 
//todos vetores da estrutura vão ser apresentados.

typedef struct {
    int id;
    char nomePopular[40];
    char nomeCientifico[50];
    char regiao[30];
    float producaoMel;
} Abelha;
//BASE. Estrutura de dados para caracteristicas:
//Quando a Struct "Abelha" for chamada em uma função, 
//todos vetores dessa vão ser apresentados.

#endif
//