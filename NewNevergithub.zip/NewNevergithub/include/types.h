#ifndef TYPES_H
#define TYPES_H

/* Estrutura para representar um sensor de monitoramento */
typedef struct {
    int id;
    char tipo[30];
    float valor;
    int idAbelha;
} Sensor;

/* Estrutura para representar uma espécie de abelha */
typedef struct {
    int id;
    char nomePopular[40];
    char nomeCientifico[50];
    char regiao[30];
    float producaoMel;
} Abelha;

#endif
