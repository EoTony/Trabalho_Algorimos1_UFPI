#ifndef ABELHA_H
#define ABELHA_H

#include "types.h"

//Protótipo de função: Indica a existencia de função X e ela recebe tal resultado
//Permite chamar as funções defiidas em um arquivo .c

int existeAbelha(Abelha p[], int id);
int quantidadeAbelha(Abelha a[]);
void printfAbelha(Abelha p);
void listarAbelhas(Abelha a[]);
void registroAbelhas(Abelha *p);
int buscaMostraAbelha(Abelha p1[], char nome[], Sensor p2[]);
int alterarAbelha(Abelha *p, int opcao);
int deletarAbelha(Abelha p1[], int id, Sensor p2[]);

#endif
