#ifndef SENSOR_H
#define SENSOR_H

#include "types.h"

int quantidadeSensores(Sensor s[]);
void printfSensor(Sensor p);
void listarSensores(Sensor s[]);
int registroSensores(Sensor *p1, Abelha *p2);
void buscarSensor(Sensor s[], int idAbelha);
int alterarSensor(Sensor *p, int opcao);
int deletarSensor(Sensor s[], int idSensor);

#endif
