//BIBLIOTECA E ARQUIVO PARA FUNCIONALIDADE DE Abelha.c:
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include "../include/abelha.h"
#include "../include/utils.h"

//Definição de um NOME para o valor atribuido a cada cor:
#define YELLOW  "\033[33m"
#define RED     "\033[31m"
#define BOLD    "\033[1m"
#define RESET   "\033[0m"

//Implementação das funções declaradas em abelha.h:

//Função para verificar se uma abelha existe pelo ID:
int existeAbelha(Abelha p[], int id){
    for(int i = 0; i < 50; i++){
        if(p[i].id == id){
            return 1;
        }
    }
    return 0;  
}

//Função para imprimir os dados de uma abelha:
void printfAbelha(Abelha p){
    printf(BOLD "ID: %d" RESET "\n", p.id);
    printf(BOLD "Nome Popular: %s" RESET "\n", p.nomePopular);
    printf(BOLD "Nome Cientifico: %s" RESET "\n", p.nomeCientifico);
    printf(BOLD "Regiao: %s" RESET "\n", p.regiao);
    printf(BOLD "Producao de Mel: %.2f kg" RESET "\n", p.producaoMel);
}

//Função para registrar os dados de uma abelha:
void registroAbelhas(Abelha *p){
    char regioes[][30] = {"Norte","Nordeste","Centro-Oeste","Sudeste","Sul"};
    int opcao;  

    
    printf(BOLD"Informe o nome popular:" RESET "\n");
    do{    
        scanf(" %39[^\n]", p->nomePopular);
        if(strlen(p->nomePopular) == 0){
            printf(RED BOLD "!!! - Nome invalido! - !!!" RESET "\n");
            printf(BOLD "Tente novamente: " RESET);
        } 
    }while(strlen(p->nomePopular) == 0);
    
    do{
        printf(BOLD "Informe o nome cientifico:" RESET "\n");
        scanf(" %49[^\n]", p->nomeCientifico);
        if(strlen(p->nomeCientifico) == 0){
            printf(RED BOLD "!!! - Nome invalido! - !!!" RESET "\n");
            printf("Tente novamente: ");
        }
    }while(strlen(p->nomeCientifico) == 0);
    
    printf(YELLOW BOLD "Escolha a regiao:" RESET "\n");
    printf(BOLD "0 - Norte" RESET "\n");
    printf(BOLD "1 - Nordeste" RESET "\n");
    printf(BOLD "2 - Centro-Oeste" RESET "\n");
    printf(BOLD "3 - Sudeste" RESET "\n");
    printf(BOLD "4 - Sul" RESET "\n");
    printf(YELLOW BOLD "Digite o numero correspondente a regiao:" RESET "\n");
    do{    
        if(scanf("%d", &opcao) != 1){
            limpezaBuffer();
            opcao = -1;
        }
        if(opcao < 0 || opcao > 4){
            printf(RED BOLD "!!! - Regiao invalida - !!!" RESET "\n");
            printf(BOLD "digite novamente: " RESET);
        }
    }while(opcao < 0 || opcao > 4);
    strcpy(p->regiao, regioes[opcao]);
    
    
    printf(BOLD "Informe a producao de mel (em kg):" RESET "\n");
    do{
        if(scanf("%f", &p->producaoMel) != 1){
            limpezaBuffer();
            p->producaoMel = -1;
        }
        if(p->producaoMel < 0){
            printf(RED BOLD "!!! - Producao invalida! - !!!" RESET "\n");
            printf("Tente novamente: ");
        }
    }while(p->producaoMel < 0);
}

//Função para contar a quantidade de abelhas cadastradas:
int quantidadeAbelha(Abelha a[]){
    int cont = 0;
    for(int i = 0; i < 50; i++){
        if(a[i].id != -1){
            cont++;
        }
    }
    return cont;
}

//Função para listar todas as abelhas cadastradas:
void listarAbelhas(Abelha a[]){
    for(int i = 0; i < 50; i++){
        if(a[i].id != -1){
            printfAbelha(a[i]);
            printf("*-------------------------*\n");
        }
    }
}

//Função para buscar e mostrar abelha pelo nome popular ou cientifico:
int buscaMostraAbelha(Abelha p1[], char nome[], Sensor p2[]){
    int existe = 0;
    for(int i = 0; i < 50; i++){
        if((p1[i].id >= 0 && strstr(p1[i].nomePopular, nome) != NULL) || 
           (p1[i].id >= 0 && strcasecmp(p1[i].nomeCientifico, nome) == 0)){
            existe = 1;
            printfAbelha(p1[i]);
            
            int temSensor = 0;
            for(int j = 0; j < 100; j++){
                if(p2[j].id != -1){
                 temSensor = 1;
                } 
            }
            if(temSensor > 0){
                printf(BOLD "Sensores associados:" RESET "\n");
                int encontrouSensor = 0;
                for(int j = 0; j < 100; j++){
                    if(p1[i].id == p2[j].idAbelha && p2[j].id != -1){
                        printf(BOLD "ID: %d" RESET "\n", p2[j].id);
                        printf(BOLD "Tipo: %s" RESET "\n", p2[j].tipo);
                        printf(BOLD "Valor: %.2f" RESET "\n", p2[j].valor);
                        printf(BOLD "ID da Abelha Associada: %d" RESET "\n", p2[j].idAbelha);
                        encontrouSensor = 1;
                    }
                }
                if(encontrouSensor == 0){
                    printf(BOLD "Nenhum sensor associado a esta abelha." RESET "\n");
                }
            }
            else{
                printf(BOLD "Nenhum sensor associado a esta abelha." RESET "\n");
            }   
            printf("---------------\n");
            printf("\n");
        }
    }
    return existe;
}
//Função para alterar os dados de uma abelha:
int alterarAbelha(Abelha *p, int opcao){
    switch(opcao){
        case 1:
            
            printf(BOLD "Informe o novo nome popular:" RESET "\n");
            do{
                scanf(" %39[^\n]", p->nomePopular);
                if(strlen(p->nomePopular) == 0){
                    printf(RED BOLD "!!! - Nome invalido - !!!" RESET "\n");
                    printf("Tente novamente: ");
                }
            }while(strlen(p->nomePopular) == 0);
            break;
        case 2:
            
            printf(BOLD "Informe o novo nome cientifico:" RESET "\n");
            do{    
                scanf(" %49[^\n]", p->nomeCientifico);
                if(strlen(p->nomeCientifico) == 0){
                    printf(RED BOLD "!!! - Nome invalido! - !!!" RESET "\n");
                    printf("Tente novamente: ");
                }
            }while(strlen(p->nomeCientifico) == 0);
            break;
        case 3:{
            char regioes[][30] = {"Norte","Nordeste","Centro-Oeste","Sudeste","Sul"};
            int opcaoRegiao;
            
            printf(YELLOW BOLD "Escolha a regiao:" RESET "\n");
            printf(BOLD "0 - Norte" RESET "\n");
            printf(BOLD "1 - Nordeste" RESET "\n");
            printf(BOLD "2 - Centro-Oeste" RESET "\n");
            printf(BOLD "3 - Sudeste" RESET "\n");
            printf(BOLD "4 - Sul" RESET "\n");
            printf(YELLOW BOLD "Digite o numero correspondente a regiao:" RESET "\n");
            do{    
                if(scanf("%d", &opcaoRegiao) != 1){
                    limpezaBuffer();
                    opcaoRegiao = -1;
                }
                if(opcaoRegiao < 0 || opcaoRegiao > 4){
                    printf(RED BOLD "!!! - Regiao invalida! - !!!" RESET "\n");
                    printf("digite novamente: ");
                }
            }while(opcaoRegiao < 0 || opcaoRegiao > 4);
            strcpy(p->regiao, regioes[opcaoRegiao]);
            break;
        }
        case 4:
            
            printf(BOLD "Informe a nova producao de mel (em kg):" RESET "\n");
            do{    
                if(scanf("%f", &p->producaoMel) != 1){
                    limpezaBuffer();
                    p->producaoMel = -1;
                }
                if(p->producaoMel < 0){
                    printf(RED BOLD "!!! - Producao invalida! - !!!" RESET "\n");
                    printf("Tente novamente: ");
                }
            }while(p->producaoMel < 0);  
            break;               
        default:
            printf(RED BOLD "!!! - Opcao invalida! - !!!" RESET "\n");
            break;
    }
    return 0;
}

//Função para deletar uma abelha e seus sensores associados:
int deletarAbelha(Abelha p1[], int id, Sensor p2[]){
    int total = quantidadeAbelha(p1);
    for(int i = 0; i < total; i++){
        if(p1[i].id == id){
            for(int j = 0; j < 100; j++){
                if(p2[j].idAbelha == id && p2[j].id != -1){
                    p2[j].id = -1;
                    p2[j].idAbelha = -1;
                    p2[j].valor = 0;
                    p2[j].tipo[0] = '\0';
                }
            }
            for(int j = i; j < total - 1; j++){
                p1[j] = p1[j+1];
                for(int k = 0; k < 100; k++){
                    if(p2[k].idAbelha == p1[j].id){
                        p2[k].idAbelha -= 1;
                    }
                }
                p1[j].id -= 1;
            }
            p1[total - 1].id = -1;
            p1[total - 1].producaoMel = 0;
            p1[total - 1].nomeCientifico[0] = '\0';
            p1[total - 1].nomePopular[0] = '\0';
            p1[total - 1].regiao[0] = '\0';
            return 1;
        }
    }
    return 0;
}
