#include <stdio.h>
#include <string.h>
#include <strings.h>
#include "../include/abelha.h"
#include "../include/utils.h"

int existeAbelha(Abelha p[], int id){
    for(int i = 0; i < 50; i++){
        if(p[i].id == id){
            return 1;
        }
    }
    return 0;  
}

void printfAbelha(Abelha p){
    printf("ID: %d\n", p.id);
    printf("Nome Popular: %s\n", p.nomePopular);
    printf("Nome Cientifico: %s\n", p.nomeCientifico);
    printf("Regiao: %s\n", p.regiao);
    printf("Producao de Mel: %.2f kg\n", p.producaoMel);
}

void registroAbelhas(Abelha *p){
    char regioes[][39] = {"Norte","Nordeste","Centro-Oeste","Sudeste","Sul"};
    int opcao;  
    
    do{
        printf("Informe o nome popular:\n");
        scanf(" %39[^\n]", p->nomePopular);
        if(strlen(p->nomePopular) == 0){
            printf("!!! Nome invalido! Tente novamente. !!!\n");
        } 
    }while(strlen(p->nomePopular) == 0);
    
    do{
        printf("Informe o nome cientifico:\n");
        scanf(" %49[^\n]", p->nomeCientifico);
        if(strlen(p->nomeCientifico) == 0){
            printf("!!! Nome invalido! Tente novamente. !!!\n");
        }
    }while(strlen(p->nomeCientifico) == 0);
    
    do{
        printf("Escolha a regiao:\n");
        printf("0 - Norte\n");
        printf("1 - Nordeste\n");
        printf("2 - Centro-Oeste\n");
        printf("3 - Sudeste\n");
        printf("4 - Sul\n");
        printf("Digite o numero correspondente a regiao:\n");
        if(scanf("%d", &opcao) != 1){
            limpezaBuffer();
            opcao = -1;
        }
        if(opcao < 0 || opcao > 4){
            printf("!!! Regiao invalida! Tente novamente. !!!\n");
        }
    }while(opcao < 0 || opcao > 4);
    strcpy(p->regiao, regioes[opcao]);
    
    do{
        printf("Informe a producao de mel (em kg):\n");
        if(scanf("%f", &p->producaoMel) != 1){
            limpezaBuffer();
            p->producaoMel = -1;
        }
        if(p->producaoMel < 0){
            printf("!!! Producao invalida! Tente novamente. !!!\n");
        }
    }while(p->producaoMel < 0);
}

int quantidadeAbelha(Abelha a[]){
    int cont = 0;
    for(int i = 0; i < 50; i++){
        if(a[i].id != -1){
            cont++;
        }
    }
    return cont;
}

void listarAbelhas(Abelha a[]){
    for(int i = 0; i < 50; i++){
        if(a[i].id != -1){
            printfAbelha(a[i]);
            printf("*-------------------------*\n");
        }
    }
}

int buscaMostraAbelha(Abelha p1[], char nome[], Sensor p2[]){
    int existe = 0;
    for(int i = 0; i < 50; i++){
        if((p1[i].id >= 0 && strstr(p1[i].nomePopular, nome) != NULL) || 
           (p1[i].id >= 0 && strcasecmp(p1[i].nomeCientifico, nome) == 0)){
            existe = 1;
            printfAbelha(p1[i]);
            
            int temSensor = 0;
            for(int j = 0; j < 100; j++){
                if(p2[j].id != -1) temSensor = 1;
            }
            
            if(temSensor > 0){
                printf("Sensores associados:\n");
                int encontrouSensor = 0;
                for(int j = 0; j < 100; j++){
                    if(p1[i].id == p2[j].idAbelha && p2[j].id != -1){
                        printf("ID: %d\n", p2[j].id);
                        printf("Tipo: %s\n", p2[j].tipo);
                        printf("Valor: %.2f\n", p2[j].valor);
                        printf("ID da Abelha Associada: %d\n", p2[j].idAbelha);
                        encontrouSensor = 1;
                    }
                }
                if(!encontrouSensor){
                    printf("Nenhum sensor associado a esta abelha.\n");
                }
            }
            else{
                printf("Nenhum sensor associado a esta abelha.\n");
            }   
            printf("---------------\n");
            printf("\n");
        }
    }
    return existe;
}

int alterarAbelha(Abelha *p, int opcao){
    switch(opcao){
        case 1:
            do{
                printf("Informe o novo nome popular:\n");
                scanf(" %39[^\n]", p->nomePopular);
                if(strlen(p->nomePopular) == 0){
                    printf("Nome invalido! Tente novamente.\n");
                }
            }while(strlen(p->nomePopular) == 0);
            break;
        case 2:
            do{
                printf("Informe o novo nome cientifico:\n");
                scanf(" %49[^\n]", p->nomeCientifico);
                if(strlen(p->nomeCientifico) == 0){
                    printf("!!! Nome invalido! Tente novamente. !!!\n");
                }
            }while(strlen(p->nomeCientifico) == 0);
            break;
        case 3:{
            char regioes[][39] = {"Norte","Nordeste","Centro-Oeste","Sudeste","Sul"};
            int opcaoRegiao;
            do{
                printf("Escolha a regiao:\n");
                printf("0 - Norte\n");
                printf("1 - Nordeste\n");
                printf("2 - Centro-Oeste\n");
                printf("3 - Sudeste\n");
                printf("4 - Sul\n");
                printf("Digite o numero correspondente a regiao:\n");
                if(scanf("%d", &opcaoRegiao) != 1){
                    limpezaBuffer();
                    opcaoRegiao = -1;
                }
                if(opcaoRegiao < 0 || opcaoRegiao > 4){
                    printf("!!! Regiao invalida! Tente novamente. !!!\n");
                }
            }while(opcaoRegiao < 0 || opcaoRegiao > 4);
            strcpy(p->regiao, regioes[opcaoRegiao]);
            break;
        }
        case 4:
            do{
                printf("Informe a nova producao de mel (em kg):\n");
                if(scanf("%f", &p->producaoMel) != 1){
                    limpezaBuffer();
                    p->producaoMel = -1;
                }
                if(p->producaoMel < 0){
                    printf("!!! Producao invalida! Tente novamente. !!!\n");
                }
            }while(p->producaoMel < 0);  
            break;               
        default:
            printf("!!! Opcao invalida! !!!\n");
            break;
    }
    return 0;
}

int deletarAbelha(Abelha p1[], int id, Sensor p2[]){
    int total = quantidadeAbelha(p1);
    for(int i = 0; i < total; i++){
        if(p1[i].id == id){
            for(int j = 0; j < 100; j++){
                if(p2[j].idAbelha == id && p2[j].id != -1){
                    p2[j].id = -1;
                    p2[j].idAbelha = -1;
                    p2[j].valor = 0;
                    p2[j].tipo[0] = '\0';
                }
            }
            for(int j = i; j < total - 1; j++){
                p1[j] = p1[j+1];
                for(int k = 0; k < 100; k++){
                    if(p2[k].idAbelha == p1[j].id){
                        p2[k].idAbelha -= 1;
                    }
                }
                p1[j].id -= 1;
            }
            p1[total - 1].id = -1;
            p1[total - 1].producaoMel = 0;
            p1[total - 1].nomeCientifico[0] = '\0';
            p1[total - 1].nomePopular[0] = '\0';
            p1[total - 1].regiao[0] = '\0';
            return 1;
        }
    }
    return 0;
}
