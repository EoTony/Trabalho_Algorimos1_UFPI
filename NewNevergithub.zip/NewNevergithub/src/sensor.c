#include <stdio.h>
#include <string.h>
#include "../include/sensor.h"
#include "../include/utils.h"

int quantidadeSensores(Sensor s[]){
    int cont = 0;
    for(int i = 0; i < 100; i++){
        if(s[i].id != -1){
            cont++;
        }
    }
    return cont;
}

void printfSensor(Sensor p){
    printf("ID: %d\n", p.id);
    printf("Tipo: %s\n", p.tipo);
    printf("Valor: %.2f\n", p.valor);
    printf("ID da Abelha Associada: %d\n", p.idAbelha);
}

int registroSensores(Sensor *p1, Abelha *p2){
    char tipo[][13] = {"Temperatura","Umidade","Luminosidade"};
    int opcao;
    
    do{
        printf("Escolha o tipo de sensor:\n");
        printf("0 - Temperatura\n");
        printf("1 - Umidade\n");
        printf("2 - Luminosidade\n");
        printf("Digite o numero correspondente ao tipo:\n");
        if(scanf("%d", &opcao) != 1){
            limpezaBuffer();
            opcao = -1;
        }
        if(opcao < 0 || opcao > 2){
            printf("!!! Tipo invalido! Tente novamente. !!!\n");
        }
    }while(opcao < 0 || opcao > 2);
    strcpy(p1->tipo, tipo[opcao]);
    
    do{
        printf("Informe o valor do sensor:\n");
        if(scanf("%f", &p1->valor) != 1){
            limpezaBuffer();
            p1->valor = -1;
        }
        if(p1->valor < 0){
            printf("!!! Valor invalido! Tente novamente. !!!\n");
        }
    }while(p1->valor < 0);
    
    do{
        printf("Informe o ID da abelha associada:\n");
        if(scanf("%d", &p1->idAbelha) == 1){
            for(int j = 0; j < 50; j++){
                if(p2[j].id == p1->idAbelha){
                    return 1;
                }
            }
        }
        else{
            printf("!!! ID de abelha invalido! !!!\n");
            limpezaBuffer();
        }
    }while(1);
    return 0;
}

void listarSensores(Sensor s[]){
    for(int i = 0; i < 100; i++){
        if(s[i].id != -1){
            printfSensor(s[i]);
            printf("*-------------------------*\n");
        }
    }
}

void buscarSensor(Sensor s[], int idAbelha){
    int existe = 0;
    for(int i = 0; i < 100; i++){
        if(s[i].idAbelha == idAbelha && s[i].id != -1){
            existe = 1;
            printfSensor(s[i]);
            printf("*-------------------------*\n");
        }
    }
    if(existe == 0){
        printf("*-------------------------*\n");
        printf("Nenhum sensor encontrado.\n");
        printf("*-------------------------*\n");
    }
}

int deletarSensor(Sensor s[], int idSensor){
    for(int i = 0; i < 100; i++){
        if(s[i].id == idSensor){
            s[i].id = -1;
            s[i].idAbelha = -1;
            s[i].valor = 0;
            s[i].tipo[0] = '\0';
            return 1;
        }
    }
    return 0;
}

int alterarSensor(Sensor *p, int opcao){
    switch(opcao){
        case 1:{
            char tipo[][13] = {"Temperatura","Umidade","Luminosidade"};
            int opcaoTipo;
            do{
                printf("Escolha o tipo de sensor:\n");
                printf("0 - Temperatura\n");
                printf("1 - Umidade\n");
                printf("2 - Luminosidade\n");
                printf("Digite o numero correspondente ao tipo:\n");
                if(scanf("%d", &opcaoTipo) != 1){
                    limpezaBuffer();
                    opcaoTipo = -1;
                }
                if(opcaoTipo < 0 || opcaoTipo > 2){
                    printf("Tipo invalido! Tente novamente.\n");
                }
            }while(opcaoTipo < 0 || opcaoTipo > 2);
            strcpy(p->tipo, tipo[opcaoTipo]);
            break;
        }
        case 2:
            do{
                printf("Informe o novo valor do sensor:\n");
                if(scanf("%f", &p->valor) != 1){
                    limpezaBuffer();
                    p->valor = -1;
                }
                if(p->valor < 0){
                    printf("Valor invalido! Tente novamente.\n");
                }
            }while(p->valor < 0);
            break;               
        default:
            printf("Opcao invalida!\n");
            break;
    }
    return 0;
}
