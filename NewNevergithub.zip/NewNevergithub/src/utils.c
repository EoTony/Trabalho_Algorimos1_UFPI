#include <stdio.h>
#include "../include/utils.h"

void limpezaBuffer(){
    int aux;
    while((aux = getchar()) != '\n' && aux != EOF);
}
