//BIBLIOTECA E ARQUIVO PARA FUNCIONALIDADE DE Utils.c:
#include <stdio.h>
#include "../include/utils.h"

//Implementação da Função para limpar o buffer do teclado:
void limpezaBuffer(){
    int aux;
    while((aux = getchar()) != '\n' && aux != EOF);
}
