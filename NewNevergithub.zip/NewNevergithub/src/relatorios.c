#include <stdio.h>
#include <string.h>
#include "../include/relatorios.h"

double temperaturaMedia(Sensor p[]){
    double soma = 0;
    int cont = 0;
    for(int i = 0; i < 100; i++){
        if(p[i].id != -1 && strcmp(p[i].tipo, "Temperatura") == 0){
            soma += p[i].valor;
            cont++;
        }
    }
    if(cont == 0){
        return 0;
    }
    return soma / cont;
}

int quantidadePorRegiao(Abelha p[], char regiao[]){
    int cont = 0;
    for(int i = 0; i < 50; i++){
        if(p[i].id != -1 && strcmp(p[i].regiao, regiao) == 0){
            cont++;
        }
    }
    return cont;
}

double producaoMediaMel(Abelha p[]){
    double soma = 0;
    int cont = 0;
    for(int i = 0; i < 50; i++){
        if(p[i].id != -1){
            soma += p[i].producaoMel;
            cont++;
        }
    }
    if(cont == 0){
        return 0;
    }
    return soma / cont;
}
