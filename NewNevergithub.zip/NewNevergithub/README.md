# Como Executar

## **Forma 1: Ctrl+Shift+B + Terminal**

1. Pressione `Ctrl+Shift+B` para compilar
2. No terminal integrado (`Ctrl+'`), digite:
   - **Linux/macOS**: `./beemonitor`
   - **Windows**: `beemonitor.exe`

## **Forma 2: Make Run**

No terminal integrado (`Ctrl+'`), digite:
- **Linux/macOS**: `make run`
- **Windows (com Make)**: `make run`
- **Windows (sem Make)**: 
  ```cmd
  gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor.exe trabalhoAlgo1.c src/abelha.c src/sensor.c src/utils.c src/relatorios.c && beemonitor.exe
  ```

## **Forma 3: Task Build and Run**

1. Pressione `Ctrl+Shift+P`
2. Digite: `Run Task`
3. Selecione: `Build and Run BeeMonitor`

(Funciona em todos os sistemas operacionais)
