//BIBLIOTECAS BÁSICAS PARA FUNCIONALIDADE DE TrabalhoAlgo1.c:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

//Bibliotecas para incluir/chamar arquivos de funções pré-programadas:
//Esses arquivos .h e .c contêm definições e implementações de funções usadas no programa.
#include "include/types.h"
#include "include/utils.h"
#include "include/abelha.h"
#include "include/sensor.h"
#include "include/relatorios.h"

//Definição de um NOME para o valor atribuido a cada cor:
#define YELLOW  "\033[33m"
#define RED     "\033[31m"
#define BOLD    "\033[1m"
#define RESET   "\033[0m"

//Função principal do programa
//MENUS e CHAMADAS de funções:
int main(){
    Abelha abelhas[50];
    Sensor sensores[100];

    //Inicializando vetores:
    for(int i = 0;i < 50;i++){
        abelhas[i].id = -1;
        abelhas[i].producaoMel = 0;
        abelhas[i].nomeCientifico[0] = '\0';
        abelhas[i].nomePopular[0] = '\0';
        abelhas[i].regiao[0] = '\0';
    }
    for(int i = 0;i < 100;i++){
        sensores[i].id = -1;
        sensores[i].idAbelha = -1;
        sensores[i].valor = 0;
        sensores[i].tipo[0] = '\0';
    }
    char opcao,opcao2,opcao3,opcao4;
    do{
        printf(YELLOW BOLD "============================================" RESET "\n");
        printf(YELLOW BOLD "=              BeeMonitor C                =" RESET "\n");
        printf(YELLOW BOLD "============================================" RESET "\n");
        printf(YELLOW BOLD "A" RESET " - " BOLD "Gerenciar Abelhas" RESET "\n");
        printf(YELLOW BOLD "B" RESET " - " BOLD "Gerenciar Sensores" RESET "\n");
        printf(YELLOW BOLD "C" RESET " - " BOLD "Relatorios" RESET "\n");
        printf(YELLOW BOLD "D" RESET " - " BOLD "Sair" RESET "\n");
        printf(YELLOW BOLD ">>> Escolha uma opcao: " RESET);
        scanf(" %c",&opcao);
        system("clear || cls");
        switch(opcao){
            case 'A':
            case 'a':
                do{
                    printf(YELLOW BOLD "============================================" RESET "\n");
                    printf(YELLOW BOLD "=        Gerenciamento de Abelhas         =" RESET "\n");
                    printf(YELLOW BOLD "============================================" RESET "\n");
                    printf(YELLOW BOLD "A" RESET " - " BOLD "Cadastrar" RESET "\n");
                    printf(YELLOW BOLD "B" RESET " - " BOLD "Listar" RESET "\n");
                    printf(YELLOW BOLD "C" RESET " - " BOLD "Buscar" RESET "\n");
                    printf(YELLOW BOLD "D" RESET " - " BOLD "Remover registros de abelhas" RESET "\n");
                    printf(YELLOW BOLD "E" RESET " - " BOLD "Alterar" RESET "\n");
                    printf(YELLOW BOLD "F" RESET " - " BOLD "Sair" RESET "\n");
                    printf(YELLOW BOLD ">>> Escolha uma opcao: " RESET);
                    scanf(" %c",&opcao2);
                    system("clear || cls");
                    switch(opcao2){
                        case 'A':
                        case 'a':
                            if(quantidadeAbelha(abelhas) == 50){
                                printf(YELLOW BOLD "*---------------------------------------*" RESET "\n");
                                printf(BOLD " Limite de abelhas cadastradas atingido." RESET "\n");
                                printf(YELLOW BOLD "*---------------------------------------*" RESET "\n");
                                break;
                            }
                            else{  
                                for(int i = 0;i < 50;i++){
                                    if(abelhas[i].id == -1){
                                        abelhas[i].id = i;
                                        registroAbelhas(&abelhas[i]);
                                        printf(YELLOW BOLD "*------------------------------*" RESET "\n");
                                        printf(BOLD " Abelha cadastrada com sucesso!" RESET "\n");
                                        printf(YELLOW BOLD "*------------------------------*" RESET "\n");
                                        break;
                                    }
                                }
                            }    
                            break;
                        case 'B':
                        case 'b':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf(YELLOW BOLD "*--------------------------*" RESET "\n");
                                printf(BOLD " Nenhuma abelha cadastrada." RESET "\n");
                                printf(YELLOW BOLD "*--------------------------*" RESET "\n");
                            }
                            else{
                                listarAbelhas(abelhas);
                                printf("\n");
                            }
                            break;
                        case 'C':
                        case 'c':
                            if(quantidadeAbelha(abelhas) != 0){
                                char nome[40];
                                
                                printf(BOLD "Informe o nome popular da abelha que deseja buscar:" RESET "\n");
                                do{
                                    scanf(" %39[^\n]",nome);
                                    if(strlen(nome) == 0){
                                        printf(RED BOLD "Nome invalido! Tente novamente." RESET "\n");
                                    }
                                }while(strlen(nome) == 0);
                                if(buscaMostraAbelha(abelhas,nome,sensores) != 0){
                                }
                                else{
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                    printf(YELLOW BOLD "Abelhas nao encontradas!" RESET "\n");
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                }
                            }
                            else{
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf(YELLOW BOLD "Nenhuma abelha cadastrada!" RESET "\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            }
                            break;
                        case 'D':
                        case 'd':
                      if(quantidadeAbelha(abelhas) == 0){
                          printf(YELLOW "*-------------------------*" RESET "\n");
                          printf("Nenhuma abelha cadastrada para remover.\n");
                          printf(YELLOW "*-------------------------*" RESET "\n");
                      }
                           else{
                                int id;
                                printf(BOLD "Informe o ID da abelha que deseja remover:" RESET "\n");
                                do{
                                    if(scanf("%d",&id) != 1){
                                        limpezaBuffer();
                                        id = -1;
                                    }
                                    if(id < 0){
                                            printf(RED BOLD "!!! ID invalido! Tente novamente. !!!" RESET "\n");
                                        }
                                }while(id < 0);
                                if(existeAbelha(abelhas,id)){
                                    char confirma;
                                    printf(BOLD "Deseja realmente remover? (digite S para confirmar)" RESET "\n");
                                    scanf(" %c",&confirma);
                                    switch (confirma){
                                    case 'S':
                                    case 's':
                                        if(deletarAbelha(abelhas,id,sensores)){
                                            printf(YELLOW "*-------------------------*" RESET "\n");
                                            printf(YELLOW BOLD "Abelha removida com sucesso!" RESET "\n");
                                            printf(YELLOW "*-------------------------*" RESET "\n");
                                        }
                                        else{
                                            printf(RED BOLD "!!! Erro ao remover abelha! !!!" RESET "\n");
                                        }
                                        break;
                                    default:
                                        printf(YELLOW "* Remocao cancelada! *" RESET "\n");
                                        break;
                                    }
                                }
                                else{
                                    printf(RED BOLD "!!! ID de abelha invalido! !!!" RESET "\n");
                                }
                            }
                            break;
                        case 'E':
                        case 'e': 
                            if(quantidadeAbelha(abelhas) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf("Nenhuma abelha cadastrada para alterar.\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                break;
                            }
                            else{
                                printf(BOLD "Informe o ID da abelha que deseja alterar:" RESET "\n");
                                int id,opcaoAlterar;
                                do{    
                                    if(scanf("%d",&id) != 1){
                                            limpezaBuffer();
                                            id = -1; 
                                            printf(RED BOLD "!!! Entrada invalida. !!!" RESET "\n");
                                            printf(BOLD "Tente novamente: " RESET);
                                    }
                                }while(id < 0);    
                                if(existeAbelha(abelhas,id)){
                                    printf(BOLD "O que deseja alterar?" RESET "\n");
                                    printf(BOLD "1 - Nome Popular" RESET "\n");
                                    printf(BOLD "2 - Nome Cientifico" RESET "\n");    
                                    printf(BOLD "3 - Regiao" RESET "\n");
                                    printf(BOLD "4 - Producao de Mel" RESET "\n");
                                    printf(BOLD "Digite o numero correspondente a opcao:" RESET "\n");
                                    do{    
                                        if(scanf("%d",&opcaoAlterar) != 1){ 
                                            limpezaBuffer(); 
                                            opcaoAlterar = -1;
                                            printf(RED BOLD "!!! Entrada invalida. !!!" RESET "\n"); 
                                            printf(BOLD "Tente novamente: " RESET);
                                        }
                                    }while(opcaoAlterar < 1 || opcaoAlterar > 4);    
                                    for(int i = 0;i < 50;i++){
                                        if(abelhas[i].id == id){
                                            alterarAbelha(&abelhas[i],opcaoAlterar);
                                            printf(YELLOW "*-------------------------*" RESET "\n");
                                            printf("Abelha alterada com sucesso!\n");
                                            printf(YELLOW "*-------------------------*" RESET "\n");
                                            break;
                                        }
                                    }
                                }
                                else{
                                    printf("!!! ID de abelha invalido! !!!\n");
                                }
                            }
                            break;
                        case 'F':
                        case 'f':
                            printf(YELLOW "*-------------------------*" RESET "\n");
                            printf("Saindo do gerenciamento de abelhas!\n");
                            printf(YELLOW "*-------------------------*" RESET "\n");
                            break;
                            default:
                                printf("!!! ERRO Opcao invalida! !!!\n");
                    }
                    printf("\n");
                    printf(YELLOW "---- Pressione enter para continuar ----" RESET "\n");
                    limpezaBuffer();
                    getchar(); 
                    system("clear || cls");
                }while(opcao2 != 'F' && opcao2 != 'f');
                break;
            case 'B':
            case 'b':
                do{
                    printf(YELLOW BOLD "============================================" RESET "\n");
                    printf(YELLOW BOLD "=         Gerenciamento de Sensores       =" RESET "\n");
                    printf(YELLOW BOLD "============================================" RESET "\n");
                    printf(YELLOW "A" RESET " - Cadastrar\n");
                    printf(YELLOW "B" RESET " - Listar\n");
                    printf(YELLOW "C" RESET " - Buscar\n");
                    printf(YELLOW "D" RESET " - Remover sensores associados a abelhas\n");
                    printf(YELLOW "E" RESET " - Alterar\n");
                    printf(YELLOW "F" RESET " - Sair\n");
                    printf(YELLOW ">> Escolha uma opcao: " RESET);
                    scanf(" %c",&opcao3);
                    system("clear || cls");
                    switch(opcao3){
                        case 'A':
                        case 'a':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf(YELLOW BOLD "Nenhuma abelha cadastrada! Cadastre uma abelha antes." RESET "\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            } 
                            else{
                                for(int i = 0;i < 100;i++){
                                    if(sensores[i].id == -1){
                                        sensores[i].id = i;
                                        registroSensores(&sensores[i],abelhas);
                                        printf(YELLOW "*-------------------------*" RESET "\n");
                                        printf(YELLOW BOLD "Sensor cadastrado com sucesso!" RESET "\n");
                                        printf(YELLOW "*-------------------------*" RESET "\n");
                                        break;
                                    }
                                }
                            }
                            break;
                        case 'B':
                        case 'b':
                            if(quantidadeSensores(sensores) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf(YELLOW BOLD "Nenhum sensor cadastrado. Cadastre um antes." RESET "\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            } 
                            else{
                                listarSensores(sensores);
                            }
                            break;
                        case 'C':
                        case 'c':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf("Nenhuma abelha cadastrada! Cadastre uma abelha antes.\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            } 
                            else{
                                int idAbelha;
                                printf(BOLD "Informe o ID da abelha para buscar seus sensores:" RESET "\n");
                                do{
                                    if(scanf("%d",&idAbelha) != 1){
                                            limpezaBuffer();
                                            idAbelha = -1;
                                        }
                                        if(idAbelha < 0){
                                            printf(RED BOLD "!!! ID invalido! !!!" RESET "\n");
                                            printf(BOLD "Tente novamente: " RESET);
                                        }
                                }while(idAbelha < 0);
                                if(existeAbelha(abelhas,idAbelha)){
                                    buscarSensor(sensores,idAbelha);
                                }
                                else{
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                    printf(RED BOLD "ID de abelha invalido!" RESET "\n");
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                }
                            }  
                            break;
                        case 'D':
                        case 'd':
                            if(quantidadeSensores(sensores) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf(YELLOW BOLD "Nenhum sensor cadastrado para remover." RESET "\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            }
                            else{
                                int idSensor;
                                printf(BOLD "Informe o ID do sensor que deseja remover:" RESET "\n");
                                do{
                                    if(scanf("%d",&idSensor) != 1){
                                            limpezaBuffer();
                                            idSensor = -1;
                                        }
                                        if(idSensor < 0){
                                            printf(RED BOLD "!!! ID invalido! !!!" RESET "\n");
                                            printf(BOLD "Tente novamente: " RESET);
                                        }
                                }while(idSensor < 0);
                                char confirma;
                                printf(BOLD "Deseja realmente remover? (digite S para confirmar)" RESET "\n");
                                scanf(" %c",&confirma);
                                switch (confirma){
                                case 'S':
                                case 's':
                                    if(deletarSensor(sensores,idSensor)){
                                        printf(YELLOW "*-------------------------*" RESET "\n");
                                        printf(YELLOW BOLD "Sensor removido com sucesso!" RESET "\n");
                                        printf(YELLOW "*-------------------------*" RESET "\n");
                                        
                                    }
                                        else{
                                        printf(RED BOLD "!!! Erro ao remover sensor! !!!" RESET "\n");
                                    }
                                    break;
                                default:
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                    printf(YELLOW BOLD "Remocao cancelada!" RESET "\n");  
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                    break;
                                }               
                            }
                            break;
                        case 'E':
                        case 'e':   
                            if(quantidadeSensores(sensores) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf("Nenhum sensor cadastrado para alterar.\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            }
                            else{
                                int idSensor,opcaoAlterar;
                                printf(BOLD "Informe o ID do sensor que deseja alterar:" RESET "\n");
                                do{
                                    if(scanf("%d",&idSensor) != 1){
                                        limpezaBuffer(); 
                                        printf(RED BOLD "!!! Entrada invalida. !!!" RESET "\n");
                                        idSensor = -1;
                                        printf(BOLD "Tente novamente: " RESET);
                                    }
                                }while(idSensor < 0);    
                                int existe = 0;
                                for(int i = 0;i < 100;i++){
                                    if(sensores[i].id == idSensor){
                                        existe = 1;
                                        printf(BOLD "O que deseja alterar?" RESET "\n");
                                        printf(BOLD "1 - Tipo" RESET "\n");
                                        printf(BOLD "2 - Valor" RESET "\n");
                                        printf(BOLD "Digite o numero correspondente a opcao:" RESET "\n");
                                        do{
                                            if(scanf("%d",&opcaoAlterar) != 1){ 
                                                    limpezaBuffer(); 
                                                    printf(RED BOLD "!!! Entrada invalida. !!!" RESET "\n"); 
                                                    printf(BOLD "Tente novamente: " RESET);
                                                }
                                        }while(opcaoAlterar < 1 || opcaoAlterar > 2);
                                        alterarSensor(&sensores[i],opcaoAlterar);
                                        printf(YELLOW "*-------------------------*" RESET "\n");
                                        printf(YELLOW BOLD "Sensor alterado com sucesso!" RESET "\n");
                                        printf(YELLOW "*-------------------------*" RESET "\n");
                                        break;
                                    }
                                }
                                if(existe == 0){
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                    printf(RED BOLD "ID de sensor invalido!" RESET "\n");
                                    printf(YELLOW "*-------------------------*" RESET "\n");
                                }
                            }
                            break;    
                        case 'F':
                        case 'f':
                            printf(YELLOW "*-------------------------*" RESET "\n");
                            printf("Saindo do gerenciamento de sensores\n");
                            printf(YELLOW "*-------------------------*" RESET "\n");
                            break;
                        default:
                            printf("!!! ERRO Opcao invalida! !!!\n");
                    
                    }
                    printf(YELLOW "---- Pressione enter para continuar ----" RESET "\n");
                    limpezaBuffer();
                    getchar();  
                    system("clear || cls");
                }while(opcao3 != 'F' && opcao3 != 'f');
                break;
            case 'C':
            case 'c':
                do{
                    printf(YELLOW BOLD "============================================" RESET "\n");
                    printf(YELLOW BOLD "=               Relatórios                =" RESET "\n");
                    printf(YELLOW BOLD "============================================" RESET "\n");
                    printf(YELLOW BOLD "A" RESET " - " BOLD "Media geral de produção de mel" RESET "\n");
                    printf(YELLOW BOLD "B" RESET " - " BOLD "Temperatura media dos sensores" RESET "\n");
                    printf(YELLOW BOLD "C" RESET " - " BOLD "Quantidade de abelhas por região" RESET "\n");
                    printf(YELLOW BOLD "D" RESET " - " BOLD "Sair" RESET "\n");
                    printf(YELLOW BOLD ">> Escolha uma opcao: " RESET);
                    scanf(" %c",&opcao4);
                    system("clear || cls");
                    switch(opcao4){
                        case 'A':
                        case 'a':
                             if(quantidadeAbelha(abelhas) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf("Nenhuma abelha cadastrada para calcular a producao media de mel.\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            } 
                            else{ 
                                printf(BOLD "Media geral de producao de mel: %.2f kg" RESET "\n",producaoMediaMel(abelhas));
                            }
                            break;
                        case 'B':
                        case 'b':
                            if(quantidadeSensores(sensores) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf("Nenhum sensor cadastrado para calcular a temperatura media.\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            }   
                            else{
                                printf(BOLD "Temperatura media dos sensores: %.2f" RESET "\n",temperaturaMedia(sensores));
                            }
                            break;
                        case 'C':
                        case 'c':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf(YELLOW "*-------------------------*" RESET "\n");
                                printf("Nenhuma abelha cadastrada!\n");
                                printf(YELLOW "*-------------------------*" RESET "\n");
                            }
                            else{  
                                int totalRegioes[5] = {0};
                                char regioes[][39] = {"Norte","Nordeste","Centro-Oeste","Sudeste","Sul"};
                                for(int i = 0;i < 5;i++){
                                    totalRegioes[i] = quantidadePorRegiao(abelhas,regioes[i]);
                                }
                                printf("Quantidade de abelhas por regiao:\n");
                                for(int i = 0;i < 5;i++){
                                    printf("%s: %d abelhas\n",regioes[i],totalRegioes[i]);
                                }
                            }
                            break;
                        case 'D':
                        case 'd':
                            printf(YELLOW BOLD "*-------------------------*" RESET "\n");
                            printf(BOLD "  Saindo dos relatórios!" RESET "\n");
                            printf(YELLOW BOLD "*-------------------------*" RESET "\n");
                            break;
                        default:
                            printf(RED "!!! ERRO Opcao invalida! !!!" RESET "\n");
                    }        
                    printf(YELLOW "---- Pressione enter para continuar ----" RESET "\n");
                    limpezaBuffer();
                    getchar();  
                    system("clear || cls");
                }while(opcao4 != 'D' && opcao4 != 'd');
            break;
            case 'D':
            case 'd':
                printf(YELLOW "*=========================*" RESET "\n");
                printf(BOLD "       Ate logo!" RESET "\n" );
                printf(YELLOW "*=========================*" RESET "\n");
                return 0;
            default:
                printf("!!! ERRO Opcao invalida! !!!\n");
                printf(YELLOW BOLD "Aperte qualquer tecla para continuar:" RESET "\n");
                getchar();      
                system("clear || cls");
        }  
    }while(1);
    return 0;
}