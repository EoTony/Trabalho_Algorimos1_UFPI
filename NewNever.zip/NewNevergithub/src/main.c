#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "abelha.h"
#include "sensor.h"
#include "utils.h"
#include "relatorios.h"

int main(){
    Abelha abelhas[50];
    Sensor sensores[100];
    for(int i = 0;i < 50;i++){
        abelhas[i].id = -1;
        abelhas[i].producaoMel = 0;
        abelhas[i].nomeCientifico[0] = '\0';
        abelhas[i].nomePopular[0] = '\0';
        abelhas[i].regiao[0] = '\0';
    }
    for(int i = 0;i < 100;i++){
        sensores[i].id = -1;
        sensores[i].idAbelha = -1;
        sensores[i].valor = 0;
        sensores[i].tipo[0] = '\0';
    }
    char opcao,opcao2,opcao3,opcao4;
    do{
    printf("============================================\n");
    printf("=              BeeMonitor C               =\n");
    printf("============================================\n");
        printf("A - Gerenciar Abelhas\n");
        printf("B - Gerenciar Sensores\n");
        printf("C - Relatorios\n");
        printf("D - Sair\n");
    printf(">> Escolha uma opcao: ");
    scanf(" %c",&opcao);
        system("clear || cls");
        switch(opcao){
            case 'A':
            case 'a':
                do{
                    printf("============================================\n");
                    printf("=        Gerenciamento de Abelhas         =\n");
                    printf("============================================\n");
                    printf("A - Cadastrar\n");
                    printf("B - Listar\n");
                    printf("C - Buscar\n");
                    printf("D - Remover registros de abelhas\n");
                    printf("E - Alterar\n");
                    printf("F - Sair\n");
                    printf(">> Escolha uma opcao: ");
                    scanf(" %c",&opcao2);
                    system("clear || cls");
                    switch(opcao2){
                        case 'A':
                        case 'a':
                            if(quantidadeAbelha(abelhas) == 50){
                                printf("*-------------------------*\n");
                                printf("Limite de abelhas cadastradas atingido.\n");
                                printf("*-------------------------*\n");
                                break;
                            }
                            else{  
                                for(int i = 0;i < 50;i++){
                                    if(abelhas[i].id == -1){
                                        abelhas[i].id = i;
                                        registroAbelhas(&abelhas[i]);
                                        printf("*-------------------------*\n");
                                        printf("Abelha cadastrada com sucesso!\n");
                                        printf("*-------------------------*\n");
                                        break;
                                    }
                                }
                            }    
                            break;
                        case 'B':
                        case 'b':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf("*-------------------------*\n");
                                printf("Nenhuma abelha cadastrada.\n");
                                printf("*-------------------------*\n");
                            }
                            else{
                                listarAbelhas(abelhas);
                                printf("\n");
                            }
                            break;
                        case 'C':
                        case 'c':
                            if(quantidadeAbelha(abelhas) != 0){
                                char nome[40];
                                do{
                                    printf("Informe o nome popular da abelha que deseja buscar:\n");
                                    scanf(" %39[^\n]",nome);
                                    if(strlen(nome) == 0){
                                        printf("Nome invalido!Tente novamente.\n");
                                    }
                                }while(strlen(nome) == 0);
                                if(buscaMostraAbelha(abelhas,nome,sensores) != 0){
                                }
                                else{
                                    printf("*-------------------------*\n");
                                    printf("Abelhas nao encontradas!\n");
                                    printf("*-------------------------*\n");
                                }
                            }
                            else{
                                printf("*-------------------------*\n");
                                printf("Nenhuma abelha cadastrada!\n");
                                printf("*-------------------------*\n");
                            }
                            break;
                        case 'D':
                        case 'd':
                      if(quantidadeAbelha(abelhas) == 0){
                          printf("*-------------------------*\n");
                          printf("Nenhuma abelha cadastrada para remover.\n");
                          printf("*-------------------------*\n");
                      }
                           else{
                                int id;
                                do{
                                    printf("Informe o ID da abelha que deseja remover:\n");
                                    if(scanf("%d",&id) != 1){
                                        limpezaBuffer();
                                        id = -1;
                                    }
                                    if(id < 0){
                                            printf("!!! ID invalido! Tente novamente. !!!\n");
                                        }
                                }while(id < 0);
                                if(existeAbelha(abelhas,id)){
                                    char confirma;
                                    printf("Deseja realmente remover?(digite S para confirmar)\n");
                                    scanf(" %c",&confirma);
                                    switch (confirma){
                                    case 'S':
                                    case 's':
                                        if(deletarAbelha(abelhas,id,sensores)){
                                            printf("*-------------------------*\n");
                                            printf("Abelha removida com sucesso!\n");
                                            printf("*-------------------------*\n");
                                        }
                                        else{
                                            printf("!!! Erro ao remover abelha! !!!\n");
                                        }
                                        break;
                                    default:
                                        printf("* Remocao cancelada! *\n");
                                        break;
                                    }
                                }
                                else{
                                    printf("!!! ID de abelha invalido! !!!\n");
                                }
                            }
                            break;
                        case 'E':
                        case 'e': {
                            printf("Informe o ID da abelha que deseja alterar:\n");
                            int id,opcaoAlterar;
                                if(scanf("%d",&id) != 1){
                                        limpezaBuffer(); 
                                        printf("!!! Entrada invalida. !!!\n"); 
                                        break; 
                                }
                            if(existeAbelha(abelhas,id)){
                                printf("O que deseja alterar?\n");
                                printf("1 - Nome Popular\n");
                                printf("2 - Nome Cientifico\n");    
                                printf("3 - Regiao\n");
                                printf("4 - Producao de Mel\n");
                                printf("Digite o numero correspondente a opcao:\n");
                                if(scanf("%d",&opcaoAlterar) != 1){ 
                                    limpezaBuffer(); 
                                    printf("!!! Entrada invalida. !!!\n"); 
                                    break; 
                                }
                                for(int i = 0;i < 50;i++){
                                    if(abelhas[i].id == id){
                                        alterarAbelha(&abelhas[i],opcaoAlterar);
                                        printf("*-------------------------*\n");
                                        printf("Abelha alterada com sucesso!\n");
                                        printf("*-------------------------*\n");
                                        break;
                                    }
                                }
                            }
                            else{
                                printf("!!! ID de abelha invalido! !!!\n");
                            }
                            break;
                        }
                        case 'F':
                        case 'f':
                            printf("*-------------------------*\n");
                            printf("Saindo do gerenciamento de abelhas!\n");
                            printf("*-------------------------*\n");
                            break;
                            default:
                                printf("!!! ERRO Opcao invalida! !!!\n");
                    }
                    printf("---- Pressione enter para continuar ----\n");
                    limpezaBuffer();
                    getchar(); 
                    system("clear || cls");
                }while(opcao2 != 'F' && opcao2 != 'f');
                break;
            case 'B':
            case 'b':
                do{
                    printf("============================================\n");
                    printf("=         Gerenciamento de Sensores       =\n");
                    printf("============================================\n");
                    printf("A - Cadastrar\n");
                    printf("B - Listar\n");
                    printf("C - Buscar\n");
                    printf("D - Remover sensores associados a abelhas\n");
                    printf("E - Alterar\n");
                    printf("F - Sair\n");
                    printf(">> Escolha uma opcao: ");
                    scanf(" %c",&opcao3);
                    system("clear || cls");
                    switch(opcao3){
                        case 'A':
                        case 'a':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf("*-------------------------*\n");
                                printf("Nenhuma abelha cadastrada! Cadastre uma abelha antes.\n");
                                printf("*-------------------------*\n");
                            } 
                            else{
                                for(int i = 0;i < 100;i++){
                                    if(sensores[i].id == -1){
                                        sensores[i].id = i;
                                        registroSensores(&sensores[i],abelhas);
                                        printf("*-------------------------*\n");
                                        printf("Sensor cadastrado com sucesso!\n");
                                        printf("*-------------------------*\n");
                                        break;
                                    }
                                }
                            }
                            break;
                        case 'B':
                        case 'b':
                            if(quantidadeSensores(sensores) == 0){
                                printf("*-------------------------*\n");
                                printf("Nenhum sensor cadastrado. Cadastre um antes.\n");
                                printf("*-------------------------*\n");
                            } 
                            else{
                                listarSensores(sensores);
                            }
                            break;
                        case 'C':
                        case 'c':
                            if(quantidadeAbelha(abelhas) == 0){
                                printf("*-------------------------*\n");
                                printf("Nenhuma abelha cadastrada! Cadastre uma abelha antes.\n");
                                printf("*-------------------------*\n");
                            } 
                            else{
                                int idAbelha;
                                do{
                                    printf("Informe o ID da abelha para buscar seus sensores:\n");
                                    if(scanf("%d",&idAbelha) != 1){
                                            limpezaBuffer();
                                            idAbelha = -1;
                                        }
                                        if(idAbelha < 0){
                                                    printf("!!! ID invalido! Tente novamente. !!!\n");
                                                }
                                }while(idAbelha < 0);
                                if(existeAbelha(abelhas,idAbelha)){
                                    buscarSensor(sensores,idAbelha);
                                }
                                    else{
                                        printf("!!! ID de abelha invalido! !!!\n");
                                    }
                            }  
                            break;
                        case 'D':
                        case 'd':
                            if(quantidadeSensores(sensores) == 0){
                                printf("*-------------------------*\n");
                                printf("Nenhum sensor cadastrado para remover.\n");
                                printf("*-------------------------*\n");
                            }
                            else{
                                int idSensor;
                                do{
                                    printf("Informe o ID do sensor que deseja remover:\n");
                                    if(scanf("%d",&idSensor) != 1){
                                            limpezaBuffer();
                                            idSensor = -1;
                                        }
                                        if(idSensor < 0){
                                            printf("!!! ID invalido! Tente novamente. !!!\n");
                                        }
                                }while(idSensor < 0);
                                char confirma;
                                printf("Deseja realmente remover?(digite S para confirmar)\n");
                                scanf(" %c",&confirma);
                                switch (confirma){
                                case 'S':
                                case 's':
                                    if(deletarSensor(sensores,idSensor)){
                                        printf("*-------------------------*\n");
                                        printf("Sensor removido com sucesso!\n");
                                        printf("*-------------------------*\n");
                                        
                                    }
                                        else{
                                        printf("!!! Erro ao remover sensor! !!!\n");
                                    }
                                    break;
                                default:
                                    printf("*-------------------------*\n");
                                    printf("Remocao cancelada!\n");  
                                    printf("*-------------------------*\n");
                                    break;
                                }               
                            }
                            break;
                        case 'E':
                        case 'e':   
                            if(quantidadeSensores(sensores) == 0){
                                printf("*-------------------------*\n");
                                printf("Nenhum sensor cadastrado para alterar.\n");
                                printf("*-------------------------*\n");
                            }
                            else{
                                int idSensor,opcaoAlterar;
                                printf("Informe o ID do sensor que deseja alterar:\n");
                if(scanf("%d",&idSensor) != 1){
                    limpezaBuffer(); 
                    printf("!!! Entrada invalida. !!!\n"); 
                    break; 
                }
                                int existe = 0;
                                for(int i = 0;i < 100;i++){
                                    if(sensores[i].id == idSensor){
                                        existe = 1;
                                        printf("O que deseja alterar?\n");
                                        printf("1 - Tipo\n");
                                        printf("2 - Valor\n");
                                        printf("Digite o numero correspondente a opcao:\n");
                                        if(scanf("%d",&opcaoAlterar) != 1){ 
                                                    limpezaBuffer(); 
                                                    printf("!!! Entrada invalida. !!!\n"); 
                                                    break; 
                                                }
                                        alterarSensor(&sensores[i],opcaoAlterar);
                                        printf("*-------------------------*\n");
                                        printf("Sensor alterado com sucesso!\n");
                                        printf("*-------------------------*\n");
                                        break;
                                    }
                                }
                                if(existe == 0){
                                    printf("*-------------------------*\n");
                                    printf("ID de sensor invalido!\n");
                                    printf("*-------------------------*\n");
                                }
                            }
                            break;    
                        case 'F':
                        case 'f':
                            printf("*-------------------------*\n");
                            printf("Saindo do gerenciamento de sensores\n");
                            printf("*-------------------------*\n");
                            break;
                        default:
                            printf("!!! ERRO Opcao invalida! !!!\n");
                    
                    }
                    printf("---- Pressione enter para continuar ----\n");
                    limpezaBuffer();
                    getchar();  
                    system("clear || cls");
                }while(opcao3 != 'F' && opcao3 != 'f');
                break;
            case 'C':
            case 'c':
                do{
                    printf("============================================\n");
                    printf("=               Relatórios                =\n");
                    printf("============================================\n");
                    printf("A - Media geral de produção de mel\n");
                    printf("B - Temperatura media dos sensores\n");
                    printf("C - Quantidade de abelhas por região\n");
                    printf("D - Sair\n");
                    printf(">> Escolha uma opcao: ");
                    scanf(" %c",&opcao4);
                    system("clear || cls");
                    switch(opcao4){
                        case 'A':
                        case 'a':
                            printf("Media geral de producao de mel: %.2f kg\n",producaoMediaMel(abelhas));
                            break;
                        case 'B':
                        case 'b':
                            printf("Temperatura media dos sensores: %.2f\n",temperaturaMedia(sensores));
                            break;
                        case 'C':
                        case 'c':
                            int totalRegioes[5] = {0};
                            char regioes[][39] = {"Norte","Nordeste","Centro-Oeste","Sudeste","Sul"};
                            for(int i = 0;i < 5;i++){
                                totalRegioes[i] = quantidadePorRegiao(abelhas,regioes[i]);
                            }
                            printf("Quantidade de abelhas por regiao:\n");
                            for(int i = 0;i < 5;i++){
                                printf("%s: %d abelhas\n",regioes[i],totalRegioes[i]);
                            }
                            break;
                        case 'D':
                        case 'd':
                            printf("*-------------------------*\n");
                            printf("Saindo dos relatórios!\n");
                            printf("*-------------------------*\n");
                            break;
                        default:
                            printf("!!! ERRO Opcao invalida! !!!\n");
                    }        
                    printf("---- Pressione enter para continuar ----\n");
                    limpezaBuffer();
                    getchar();  
                    system("clear || cls");
                }while(opcao4 != 'D' && opcao4 != 'd');
            break;
            case 'D':
            case 'd':
                printf("*=========================*\n");
                printf("Ate logo!\n");
                printf("*=========================*\n");
                return 0;
            default:
                printf("!!! ERRO Opcao invalida! !!!\n");
        }        
        system("clear || cls");
    }while(1);
    return 0;
}