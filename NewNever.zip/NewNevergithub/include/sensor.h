#ifndef SENSOR_H
#define SENSOR_H

#include "types.h"

/* Módulo de gerenciamento de sensores */

/* Exibe informações de um sensor */
void printfSensor(Sensor p);

/* Retorna a quantidade de sensores cadastrados */
int quantidadeSensores(Sensor s[]);

/* Realiza o cadastro interativo de um novo sensor */
int registroSensores(Sensor *p1, Abelha *p2);

/* Lista todos os sensores cadastrados */
void listarSensores(Sensor s[]);

/* Busca e exibe sensores de uma abelha específica */
void buscarSensor(Sensor s[], int idAbelha);

/* Remove um sensor pelo ID */
int deletarSensor(Sensor s[], int idSensor);

/* Altera dados de um sensor existente */
int alterarSensor(Sensor *p, int opcao);

#endif
