#ifndef ABELHA_H
#define ABELHA_H

#include "types.h"

/* Módulo de gerenciamento de abelhas */

/* Verifica se existe uma abelha com o ID fornecido */
int existeAbelha(Abelha p[], int id);

/* Exibe informações de uma abelha */
void printfAbelha(Abelha p);

/* Realiza o cadastro interativo de uma nova abelha */
void registroAbelhas(Abelha *p);

/* Retorna a quantidade de abelhas cadastradas */
int quantidadeAbelha(Abelha a[]);

/* Altera dados de uma abelha existente */
int alterarAbelha(Abelha *p, int opcao);

/* Remove uma abelha e seus sensores associados */
int deletarAbelha(Abelha p1[], int id, Sensor p2[]);

/* Busca e exibe abelhas por nome (popular ou científico) */
int buscaMostraAbelha(Abelha p1[], char nome[], Sensor p2[]);

/* Lista todas as abelhas cadastradas */
void listarAbelhas(Abelha a[]);

#endif
