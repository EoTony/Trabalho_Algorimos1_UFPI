#include <stdio.h>
#include <stdlib.h>

int main(){
    const char *comando;
    const char *executavel;

    // Detectando o sistema operacional
    #ifdef _WIN32
        // Windows
        comando = "gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor src/main.c src/abelha.c src/sensor.c src/utils.c src/relatorios.c";
        executavel = "beemonitor.exe";
    #else
        // Linux, macOS ou outros sistemas Unix-like
        comando = "gcc -Wall -Wextra -std=c11 -Iinclude -o beemonitor src/main.c src/abelha.c src/sensor.c src/utils.c src/relatorios.c";
        executavel = "./beemonitor";
    #endif

    printf("Compilando o projeto BeeMonitor...\n");

    // Executa o comando de compilação
    int retorno = system(comando);

    // Verifica se a compilação foi bem-sucedida
    if (retorno == 0)
    {
        printf("Compilacao concluida com sucesso!\n");
        printf("Executando o programa...\n\n");
        system(executavel);
    }
    else
    {
        printf("Erro durante a compilacao. Codigo de retorno: %d\n", retorno);
        printf("Certifique-se de que esta executando este programa no diretorio raiz do projeto.\n");
    }

    return 0;
}
