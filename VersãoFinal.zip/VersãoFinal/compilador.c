#include <stdio.h>
#include <stdlib.h>

int main()
{
    const char *comando;
    const char *executavel;
    
    // Detectando o sistema operacional
    #ifdef _WIN32
        // Windows - usa ..\ para voltar da pasta output
        comando = "gcc -o beemonitor.exe ../src/trabalhoAlgo1.c ../src/abelha.c ../src/sensor.c ../src/relatorios.c ../src/utils.c -I ../include -Wall -Wextra";
        executavel = "beemonitor.exe";
    #else
        // Linux - usa ../ para voltar da pasta output
        comando = "gcc -o beemonitor ../src/trabalhoAlgo1.c ../src/abelha.c ../src/sensor.c ../src/relatorios.c ../src/utils.c -I ../include -Wall -Wextra";
        executavel = "./beemonitor";
    #endif

    printf("Compilando o projeto...\n");
    int retorno = system(comando);
    
    if (retorno == 0) {
        printf("Executando...\n\n");
        system(executavel);
    } else {
        printf("Erro na compilacao. Codigo de retorno: %d\n", retorno);
    }

    return 0;
}