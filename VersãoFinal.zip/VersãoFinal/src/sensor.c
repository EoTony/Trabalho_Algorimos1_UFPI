//BIBLIOTECAS E ARQUIVOS PARA FUNCIONALIDADE DE Sensor.c:
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../include/sensor.h"
#include "../include/utils.h"

//Definição de um NOME para o valor atribuido a cada cor:
#define YELLOW  "\033[33m"
#define RED     "\033[31m"
#define BOLD    "\033[1m"
#define RESET   "\033[0m"

//Implementação das funções declaradas em sensor.h:

//Função para contar a quantidade de sensores cadastrados:
int quantidadeSensores(Sensor s[]){
    int cont = 0;
    for(int i = 0; i < 100; i++){
        if(s[i].id != -1){
            cont++;
        }
    }
    return cont;
}

//Função para imprimir os dados de um sensor:
void printfSensor(Sensor p){
    printf(BOLD "ID: %d" RESET "\n", p.id);
    printf(BOLD "Tipo: %s" RESET "\n", p.tipo);
    printf(BOLD "Valor: %.2f" RESET "\n", p.valor);
    printf(BOLD "ID da Abelha Associada: %d" RESET "\n", p.idAbelha);
}

//Função para registrar os dados de um sensor:
int registroSensores(Sensor *p1, Abelha *p2){
    char tipo[][13] = {"Temperatura","Umidade","Luminosidade"};
    int opcao;
    
    //Solicitar o TIPO do sensor:
    printf(YELLOW BOLD "Escolha o tipo de sensor:" RESET "\n");
    printf(BOLD "0 - Temperatura" RESET "\n");
    printf(BOLD "1 - Umidade" RESET "\n");
    printf(BOLD "2 - Luminosidade" RESET "\n");
    printf(YELLOW BOLD "Digite o numero correspondente ao tipo:" RESET "\n");
    do{
        if(scanf("%d", &opcao) != 1){
            limpezaBuffer();
            opcao = -1;
        }
        if(opcao < 0 || opcao > 2){
            printf(RED BOLD "!!! - Tipo invalido! - !!!" RESET "\n");
            printf("digite novamente: ");
        }
    }while(opcao < 0 || opcao > 2);
    strcpy(p1->tipo, tipo[opcao]);

    //Solicitar o VALOR do sensor:
    
    printf(BOLD "Informe o valor do sensor:" RESET "\n");
    do{
        if(scanf("%f", &p1->valor) != 1){
            limpezaBuffer();
            p1->valor = -1;
        }
        if(p1->valor < 0){
            printf(RED BOLD "!!! - Valor invalido! - !!!" RESET "\n");
            printf("digite novamente: ");
        }
    }while(p1->valor < 0);

    //Associar o sensor a uma abelha existente:
    
    printf(BOLD "Informe o ID da abelha associada:" RESET "\n");
    do{
        if(scanf("%d", &p1->idAbelha) == 1){
            for(int j = 0; j < 50; j++){
                if(p2[j].id == p1->idAbelha){
                    return 1;
                }
            }
        }
        else{
            printf(RED BOLD "!!! - ID de abelha invalido! - !!!" RESET "\n");
            limpezaBuffer();
            printf("digite novamente: ");
        }
    }while(1);
    return 0;
}

//Função para listar todos os sensores cadastrados:
void listarSensores(Sensor s[]){
    for(int i = 0; i < 100; i++){
        if(s[i].id != -1){
            printfSensor(s[i]);
            printf(YELLOW "*-------------------------*" RESET "\n");
        }
    }
}

//Função para buscar sensores por ID da abelha associada:
void buscarSensor(Sensor s[], int idAbelha){
    int existe = 0;
    for(int i = 0; i < 100; i++){
        if(s[i].idAbelha == idAbelha && s[i].id != -1){
            existe = 1;
            printfSensor(s[i]);
            printf(YELLOW "*-------------------------*" RESET "\n");
        }
    }
    if(existe == 0){
        printf(BOLD "*-------------------------*" RESET "\n");
        printf(BOLD " Nenhum sensor encontrado." RESET "\n");
        printf(BOLD "*-------------------------*" RESET "\n");
    }
}

//Função para deletar um sensor pelo ID:
int deletarSensor(Sensor s[], int idSensor){
    for(int i = 0; i < 100; i++){
        if(s[i].id == idSensor){
            s[i].id = -1;
            s[i].idAbelha = -1;
            s[i].valor = 0;
            s[i].tipo[0] = '\0';
            return 1;
        }
    }
    return 0;
}

//Função para alterar os dados de um sensor:
int alterarSensor(Sensor *p, int opcao){
    switch(opcao){
        //Caso para alterar o TIPO do sensor:
        case 1:{
            char tipo[][13] = {"Temperatura","Umidade","Luminosidade"};
            int opcaoTipo;
            
            printf(YELLOW BOLD "Escolha o tipo de sensor:" RESET "\n");
            printf(BOLD "0 - Temperatura" RESET "\n");
            printf(BOLD "1 - Umidade" RESET "\n");
            printf(BOLD "2 - Luminosidade" RESET "\n");
            printf(YELLOW BOLD "Digite o numero correspondente ao tipo:" RESET "\n");
            do{
                if(scanf("%d", &opcaoTipo) != 1){
                    limpezaBuffer();
                    opcaoTipo = -1;
                }
                if(opcaoTipo < 0 || opcaoTipo > 2){
                    printf(RED BOLD "!!! - Tipo invalido! - !!!" RESET "\n");
                    printf("digite novamente: ");
                }
            }while(opcaoTipo < 0 || opcaoTipo > 2);
            strcpy(p->tipo, tipo[opcaoTipo]);
            break;
        }
        //Caso para alterar o VALOR do sensor:
        case 2:
            printf(BOLD "Informe o novo valor do sensor:" RESET "\n");
            do{    
                if(scanf("%f", &p->valor) != 1){
                    limpezaBuffer();
                    p->valor = -1;
                }
                if(p->valor < 0){
                    printf(RED BOLD "!!! - Valor invalido! - !!!" RESET "\n");
                    printf("digite novamente: ");
                }
            }while(p->valor < 0);
            break;               
        default:
            printf(RED BOLD "!!! - Opcao invalida! - !!!" RESET "\n");
            break;
    }
    return 0;
}
