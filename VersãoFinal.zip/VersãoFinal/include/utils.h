#ifndef UTILS_H
#define UTILS_H

void limpezaBuffer();

//Protótipo de função: Indica a existencia de função X e ela recebe tal resultado
//Permite chamar as funções defiidas em um arquivo .c

#endif
