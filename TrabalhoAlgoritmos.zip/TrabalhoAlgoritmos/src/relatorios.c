//BIBLIOTECA E ARQUIVO PARA FUNCIONALIDADE DE Relatorios.c:
#include <stdio.h>
#include <string.h>
#include "relatorios.h"

//Implementacao das funcoes declaradas em relatorios.h:

//Funcao para gerar relatorio de Temperatura media:
double temperaturaMedia(Sensor p[]){
    double soma = 0;
    int cont = 0;
    for(int i = 0; i < 100; i++){
        if(p[i].id != -1 && strcmp(p[i].tipo, "Temperatura") == 0){
            soma += p[i].valor;
            cont++;
        }
    }
    if(cont == 0){
        return 0;
    }
    return soma / cont;
}

//Funcao para contar quantidade de abelhas por regiao:
int quantidadePorRegiao(Abelha p[], char regiao[]){
    int cont = 0;
    for(int i = 0; i < 50; i++){
        if(p[i].id != -1 && strcmp(p[i].regiao, regiao) == 0){
            cont++;
        }
    }
    return cont;
}

//Funcao para gerar relatorio de producao media de mel:
double producaoMediaMel(Abelha p[]){
    double soma = 0;
    int cont = 0;
    for(int i = 0; i < 50; i++){
        if(p[i].id != -1){
            soma += p[i].producaoMel;
            cont++;
        }
    }
    if(cont == 0){
        return 0;
    }
    return soma / cont;
}
