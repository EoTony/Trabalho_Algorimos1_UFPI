//BIBLIOTECA E ARQUIVO PARA FUNCIONALIDADE DE Utils.c:
#include <stdio.h>
#include "utils.h"

//Implementacao da Funcao para limpar o buffer do teclado:
void limpezaBuffer(){
    int aux;
    while((aux = getchar()) != '\n' && aux != EOF);
}
